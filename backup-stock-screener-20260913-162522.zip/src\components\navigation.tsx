'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Star, BarChart3, Settings, LogOut, GitCompareArrows, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { ADMIN_EMAILS } from '@/lib/config';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Watchlist', href: '/watchlist', icon: Star },
  { name: 'Bandingkan', href: '/compare', icon: GitCompareArrows },
  { name: 'Akurasi', href: '/accuracy', icon: BarChart3 },
  { name: 'Pengaturan', href: '/settings', icon: Settings },
];

export function Navigation() {
  const pathname = usePathname();
  const [loggingOut, setLoggingOut] = useState(false);
  const [isAdmin, setIsAdmin] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('is_admin') === 'true';
    }
    return false;
  });

  useEffect(() => {
    fetch('/api/auth/me')
      .then(r => r.json())
      .then(data => {
        if (data.success && data.data?.email) {
          const admin = ADMIN_EMAILS.includes(data.data.email.toLowerCase());
          setIsAdmin(admin);
          localStorage.setItem('is_admin', String(admin));
        } else {
          setIsAdmin(false);
          localStorage.removeItem('is_admin');
        }
      })
      .catch(() => {});
  }, []);

  const handleLogout = async () => {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      localStorage.removeItem('is_admin');
      await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'logout' }),
      });
      window.location.href = '/login';
    } catch {
      window.location.href = '/login';
    }
  };

  if (pathname === '/login') return null;

  const items = isAdmin
    ? [...navigation, { name: 'Admin', href: '/admin', icon: Shield }]
    : navigation;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-xl border-t border-gray-800">
      <div className="overflow-x-auto scrollbar-hide">
        <div className="flex items-center justify-center h-16 min-w-max px-2 lg:px-4">
          {items.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex flex-col items-center gap-1 px-3 py-2 text-xs font-medium transition-colors shrink-0',
                  isActive
                    ? 'text-cyan-400'
                    : 'text-gray-500 hover:text-gray-300'
                )}
              >
                <item.icon className={cn('w-5 h-5', isActive && 'text-cyan-400')} />
                <span>{item.name}</span>
                {isActive && (
                  <div className="w-1 h-1 rounded-full bg-cyan-400" />
                )}
              </Link>
            );
          })}
          <button
            onClick={handleLogout}
            disabled={loggingOut}
            className="flex flex-col items-center gap-1 px-3 py-2 text-xs font-medium text-gray-500 hover:text-red-400 transition-colors shrink-0"
          >
            <LogOut className="w-5 h-5" />
            <span>{loggingOut ? '...' : 'Logout'}</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
